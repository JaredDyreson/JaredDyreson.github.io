//
//  counting.h
//  recursion_patterns
//
//  Created by William McCarthy on 10/9/18.
//  Copyright © 2018 William McCarthy. All rights reserved.
//

#ifndef counting_h
#define counting_h
#include "begin_end_test.h"

//===========================================================================
// RECURSIVE FUNCTIONS that count matching patterns
//===========================================================================
// USE std::function<return(a,b,...)> fn to handle ANY function
//    write our own version of the standard library's countif function...
//===========================================================================
// IF PRED return 1, else 0 -- maps any value of a to either 1 or 0
//    depending on the predicate
//
// this code NEVER CHANGES
//===================================

size_t onezero(int a, const std::function<size_t(int)>& pred ) { return pred(a) ? 1 : 0; }

//===================================
//subset of array...
//
// this code NEVER CHANGES
//===================================
size_t countif(int* p, size_t start, size_t end,
               const std::function<size_t(int)>& pred ) {
  if (start == end) { return onezero(p[start], pred); }
  return onezero(p[start], pred) + countif(p, start + 1, end, pred);
}
//===================================
// whole array...
//
// this code NEVER CHANGES
//===================================
size_t countif(int* p, size_t n,
               const std::function<size_t(int)>& pred ) {
  if (n == 1) { return onezero(*p, pred); }
  return onezero(*p, pred) + countif(p + 1, n - 1, pred);
}

//===========================================================================
// write a SPECIFIC function for EACH calculation...
//===========================================================================
//subset of array...
//
// MUST write new version for counting each type of condition
//===================================
size_t onezero_odds(int a) { return abs(a) % 2 == 1 ? 1 : 0; }

size_t countodds(int* p, size_t start, size_t end) {
  if (start == end) { return onezero_odds(p[start]); }
  return onezero_odds(p[start]) + countodds(p, start + 1, end);
}
//===================================
// whole array...
//
// MUST write new version for counting each type of condition
//===================================
size_t onezero_zeros(int a) { return a == 0 ? 1 : 0; }
                           
size_t countzeros(int* p, size_t n) {
  if (n == 1) { return onezero_zeros(*p); }
  return onezero_zeros(*p) + countzeros(p + 1, n - 1);
}


void test_counting() {
  begin_end_test bet(__FUNCTION__);
  
  int x[] = { 7, 0, -3, -19, -1, 5, 3, 8, 44, 21, 16, -8 };
  size_t start = 2;
  size_t end = 9;
  size_t n = sizeof(x) / sizeof(int);
  
  std::cout << "COUNT how many elements match the predicate...\n";
  std::cout << "for array: ";
  for (auto el : x) { std::cout << el << " "; }

  std::cout << "\n----------------------------------";
  std::cout << "using LAMBDA/std::function<T>s...\n";
  std::cout << "countif notpos subset [" << start << "," << end << "]: "
            << countif(x, start, end,
                       [](int a) { return a >= 0; } );
  std::cout << "\ncountif notzeros all: "
            << countif(x, n,
                       [](int a) { return a != 0; } );
  
  std::cout << "\n-----------------------------------";
  std::cout << "directly calling specific functions...\n";
std::cout << "countodds subset: [" << start << "," << end << "]: "
            << countodds(x, start, end);
  std::cout << "\n-----\ncountzeros all: [" << start << "," << end << "]: "
            << countzeros(x, n) << "\n";
}

#endif /* counting_h */
