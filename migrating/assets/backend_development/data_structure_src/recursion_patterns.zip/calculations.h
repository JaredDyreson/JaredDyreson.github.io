//
//  calculations.h
//  recursion_patterns
//
//  Created by William McCarthy on 10/9/18.
//  Copyright © 2018 William McCarthy. All rights reserved.
//

#ifndef calculations_h
#define calculations_h
#include "begin_end_test.h"

//===========================================================================
// RECURSIVE FUNCTIONS that perform CALCULATIONS
//===========================================================================
// USE std::function<return(a,b,...)> fn to handle ANY function
//===================================
// subset of array version...
//===========================================================================
template <typename T>
T calc(T* p, size_t start, size_t end,
       const std::function<T(T,T)>& FN) {
  if (start == end) { return p[start]; }
  return FN(p[start], calc(p, start + 1, end, FN));
}

// e.g.,
//double val = calc(*p, start, end,
//                  [](double a, double b) {  return a + b; });
//double val = calc(*p, start, end,
//                  [](double a, double b) { return a * b; });
//double val = calc(*p, start, end,
//                  [](double a, double b) { return a == b; });
//double val = calc(*p, start, end,
//                  [](double a, double b) { return std::max(a, b); });
//double val = calc(*p, start, end,
//                  [](double a, double b) { return pow(a, b); ));

//===================================
// whole array...
//===================================
template <typename T>
T calc(T* p, size_t n, const std::function<T(T,T)>& fn) {
  if (n == 1) { return *p; }
  return fn(*p, calc(p + 1, n - 1, fn));
}

//===========================================================================
// write a SPECIFIC function for EACH calculation...
//===================================
//subset of array version...
//===========================================================================
template <typename T>
T prod(T* p, size_t start, size_t end) {
  if (start == end) { return p[start]; }
  return p[start] * prod(p, start + 1, end);
}
//===================================
// whole array...
//===================================
template <typename T>
T max(T* p, size_t n) {
  if (n == 1) { return *p; }
  return std::max(*p, max(p + 1, n - 1));
}

void test_calculations() {
  begin_end_test bet(__FUNCTION__);
  int x[] = { 7, 0, -3, -19, -1, 5, 3, 8, 44, 21, 16, -8 };
  size_t start = 2;
  size_t end = 9;
  size_t n = sizeof(x) / sizeof(int);
  
  std::cout << "CALCULATE the results of applying various functions to an array...\n";
  std::cout << "for array: ";
  for (auto el : x) { std::cout << el << " "; }
  std::cout << "\n-----------------------------------";
  std::cout << "using LAMBDA/std::function<T>s...\n";
  std::cout << "calc sum subset: "
            << calc<int>(x, start, end,
                         [](int a, int b){ return a + b; });
  std::cout << "\ncalc max subset: "
            << calc<int>(x, start, end,
                         [](int a, int b){ return std::max(a, b); });
  std::cout << "\ncalc min ALL: "
            << calc<int>(x, n,
                         [](int a, int b){ return std::min(a, b); });

  std::cout << "\n-----------------------------------";
  std::cout << "directly calling specific functions...\n";
  std::cout << "prod subset: " << prod(x, start, end) << "\n";
  std::cout << "-----\nmax ALL: "     << max(x, n) << "\n";
}


#endif /* calculations_h */
