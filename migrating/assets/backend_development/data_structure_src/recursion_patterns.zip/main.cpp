//
//  main.cpp
//  recursion_patterns
//
//  Created by William McCarthy on 10/7/18.
//  Copyright © 2018 William McCarthy. All rights reserved.
//


#include <iostream>
#include <algorithm>

#include <iostream>
#include <algorithm>

#include "calculations.h"
#include "counting.h"


int main(int argc, const char * argv[]) {
  test_calculations();
  test_counting();

  std::cout << "\n\t\t...done.\n";
  return 0;
}
