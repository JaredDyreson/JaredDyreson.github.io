//
//  tree.h
//  trees
//
//  Created by William McCarthy on 10/31/18.
//  Copyright © 2018 William McCarthy. All rights reserved.
//

#ifndef tree_h
#define tree_h

#include <iostream>
#include <initializer_list>
#include <iomanip>
#include <sstream>
#include <queue>
#include <cmath>
#include "begin_end_test.h"


template <typename T> struct treenode_;

// truncates pointer to least significant part
// e.g., abcd efgh ijkl mnop --> mnop 0000 0000 0000 --> 0000 0000 0000 mnop
template <typename T>
size_t truncate(const treenode_<T>* p, size_t bits=48) {
  size_t value = reinterpret_cast<size_t>(p);   // pretend ptr is a size_t
  return (value << bits) >> bits;
}


//---- class treenode_<T> -------------------------------------------------------------
template <typename T>
struct treenode_ {
  treenode_() : treenode_( T() ) {}
  treenode_(const T& data, treenode_<T>* parent=nullptr, treenode_<T>* left=nullptr, treenode_<T>* right=nullptr, size_t freq=0)
  : data_(data), freq_(freq), parent_(parent), left_(left), right_(right) {}
  
  friend bool operator<(const treenode_<T>& a, const treenode_<T>& b) {
    return a.data_ < b.data_;
  }
  friend std::ostream& operator<<(std::ostream& os, const treenode_<T>& no) {
    return os << no.data_ << " x" << no.freq_ << " ("
              << truncate(&no) << "), Parent: " << truncate(no.parent_)
              << ", Left: " << truncate(no.left_) << ", Right: " << truncate(no.right_) << ")";
  }
  T data_;
  size_t freq_;
  treenode_<T>* parent_;
  treenode_<T>* left_;
  treenode_<T>* right_;
};

enum class traversal { INORDER, PREORDER, POSTORDER, LEVELORDER, REVERSE_INORDER };


//---- class tree_<T> ----------------------------------------------------------------
template <typename T>
class tree_ {
public:
  tree_() : root_(nullptr), size_(0) {}
  
  //---- INITIALIZER_LIST-------------------------------------------------------------
  tree_(const std::initializer_list<T>& li) {
    for (auto el : li) { insert(el); }
  }
  tree_& operator=(const std::initializer_list<T>& li) {
    for (auto el : li) { insert(el); }
    return *this;
  }
  
  //---- EMPTY, SIZE ------------------------------------------------------------------
  bool empty() const { return size_ == 0; }
  size_t size() const { return size_; }
  
  //---- INSERT ------------------------------------------------------------------
  void insert(const T& data) { insert(root_, data); }
  void insert(treenode_<T>*& root, const T& data, treenode_<T>* parent=nullptr) {
    if (root == nullptr) { root = new treenode_<T>(data, parent);   ++size_;  return; }
    
    if (data < root->data_)        { insert(root->left_, data, root);
    } else if (data > root->data_) { insert(root->right_, data, root);
    } else { root->freq_ += 1; }
  }
  
  //---- FIND --------------------------------------------------------------------
  treenode_<T>* find(const T& data) const { return find(root_, data); }
  treenode_<T>* find(treenode_<T>* root, const T& data) const {
    if (root == nullptr || root->data_ == data) { return root; }
    
    if (data < root->data_) { return find(root->left_, data);
    } else                  { return find(root->right_, data);
    }
  }
  
  
  //---- FIND CLOSEST-------------------------------------------------------------
  treenode_<T>* findclosest(const T& data) const {
    if (empty()) { std::cout << "cannot find: tree is empty";   return nullptr; }
    
    std::cout << "find closest to: " << data << ": ";
    treenode_<T>* p = findclosest(root_, data);
    std::cout << p->data_ << "\n";
    return p;
  }
  treenode_<T>* findclosest(treenode_<T>* root, const T& data) const {
    if (root == nullptr || root->data_ == data) { return root; }
    
    treenode_<T>* p = findclosest((data < root->data_ ? root->left_ : root->right_), data);
    if (p == nullptr) { return root; }
    
    T childdelta = p->data_ - data;
    T delta = root->data_ - data;
    return (abs(childdelta) < abs(delta) ? p : root);
  }
  
  //---- FIND MINIMUM -------------------------------------------------------------
  treenode_<T>* findminimumnode() const {
    if (empty()) { throw new std::invalid_argument("empty tree"); }
    return findminimumnode(root_, root_->data_);
  }
  treenode_<T>* findminimumnode(treenode_<T>* root) const {
    if (root->left_ == nullptr) { return root; }
    return findminimumnode(root->left_);
  }
  
  
  //---- REMOVE ------------------------------------------------------------------
  void remove(const T& data) {
    if (empty()) { throw new std::range_error("tree is empty"); }
    
    std::cout << "\nremoving " << data << " from the tree...\n";
    remove(root_, data);
    std::cout << "...after removing " << data << " tree is: \n\n";
    print();
  }
  void remove(treenode_<T>*& root, const T& data) {
    if (root == nullptr) { return; }
    if (size() == 1 && root->data_ == data) { delete root;  --size_;   return; }
    
    if (       data < root->data_) { remove(root->left_, data);   return;
    } else if (data > root->data_) { remove(root->right_, data);  return;
    }
    
    bool left_nullptr = (root->left_ == nullptr);
    bool right_nullptr = (root->right_ == nullptr);
    treenode_<T>* parent = root->parent_;
    treenode_<T>*& p = (root->data_ < parent->data_ ? parent->left_ : parent->right_);
    
    if (left_nullptr && right_nullptr) {   // no children
      p = nullptr;   // set parent's ptr to me to be the nullptr
      delete root;   // delete me
      --size_;
    } else if ((left_nullptr && !right_nullptr) || (right_nullptr && !left_nullptr)) {  // one child
      treenode_<T>*& child = right_nullptr ? root->left_ : root->right_;  // get the child
      child->parent_ = parent;  // point child at parent
      p = child;               // point parent at child
      delete root;             // delete me
      --size_;
    } else {  // two children
      treenode_<T>* minnode = findminimumnode(root->right_);  // find min node on my right
      T data = minnode->data_;
      root->data_ = data;                     // change my value to match it (promoting it to me)
      remove(root->right_, data);                                    // remove the min node
    }
  }
  
  //---- COUNT LEVELS in the tree or below a given node
  size_t count_levels() const { return count_levels(root_); }
  size_t count_levels(treenode_<T>* root) const {
    if (root == nullptr) { return 0; }
    return 1 + std::max(count_levels(root->left_), count_levels(root->right_));
  }
  //---- HEIGHT of a given node
  size_t height_node(const T& data) const {
    treenode_<T>* p = find(data);
    if (p == nullptr) { throw new std::invalid_argument("data not found"); }
    return height_node(p);
  }
  size_t height_node(treenode_<T>* root) const {
    if (root == nullptr || (root->left_ == nullptr && root->right_ == nullptr)) { return 0; }
    return 1 + std::max(height_node(root->left_), height_node(root->right_));
  }
  //---- COUNT NODES with (possibly zero) CHILDREN
  size_t count_nochildren() const { return count_nochildren(root_); }
  size_t count_nochildren(treenode_<T>* root) const {
    if (root == nullptr) { return 0; }
    return count_nochildren(root->left_) + count_nochildren(root->right_)
           + (root->left_ == nullptr && root->right_ == nullptr ? 1 : 0);
  }

  size_t count_onechild() const { return count_onechild(root_); }
  size_t count_onechild(treenode_<T>* root) const {
    if (root == nullptr) { return 0; }
    return count_onechild(root->left_) + count_onechild(root->right_)
    + ((root->left_ != nullptr && root->right_ == nullptr) ||
       (root->left_ == nullptr && root->right_ != nullptr) ? 1 : 0);
  }

  size_t count_twochildren() const { return count_twochildren(root_); }
  size_t count_twochildren(treenode_<T>* root) const {
    if (root == nullptr) { return 0; }
    return count_twochildren(root->left_) + count_twochildren(root->right_)
           + (root->left_ != nullptr && root->right_ != nullptr ? 1 : 0);
  }

  //---- PRINT    ------------------------------------------------------------
  void print() const { print(traversal::INORDER); }
  
  void print(const traversal& tr) const {
    switch(tr) {
      case traversal::INORDER:         print_inorder();         break;
      case traversal::PREORDER:        print_preorder();        break;
      case traversal::POSTORDER:       print_postorder();       break;
      case traversal::LEVELORDER:      print_levelorder();      break;
      case traversal::REVERSE_INORDER: print_reverseinorder();  break;
      default:                         print_inorder();         break;
    }
  }
  void print_inorder() const { print_inorder(root_); }
  void print_inorder(treenode_<T>* root) const {    // L me R
    if (root == nullptr) { return; }
    print_inorder(root->left_);
    std::cout << *root << " height(" << height_node(root->data_) << ")\n";
    print_inorder(root->right_);
  }
  void print_reverseinorder() const { print_reverseinorder(root_); }
  void print_reverseinorder(treenode_<T>* root) const {    // R me L
    if (root == nullptr) { return; }
    print_reverseinorder(root->right_);   std::cout << *root << "\n";   print_reverseinorder(root->left_);
  }
  void print_preorder() const { print_preorder(root_); }
  void print_preorder(treenode_<T>* root) const {    // me L R
    if (root == nullptr) { return; }
    std::cout << *root << "\n";    print_preorder(root->left_);   print_preorder(root->right_);
  }
  void print_postorder() const { print_postorder(root_); }
  void print_postorder(treenode_<T>* root) const {   // L R me
    if (root == nullptr) { return; }
    print_postorder(root->left_);    print_postorder(root->right_);    std::cout << *root << "\n";
  }
  void print_levelorder() const {
    std::queue<treenode_<T>*> levelnodes;
    levelnodes.push(root_);
    print_levelorder(root_, levelnodes); }
  void print_levelorder(treenode_<T>* root, std::queue<treenode_<T>*>& levelnodes) const {
    if (root == nullptr) { return; }

    size_t n = levelnodes.size();
    while (n-- > 0) {
      treenode_<T>* next = levelnodes.front();
      levelnodes.pop();
      std::cout << *next << "\n";

      if (next->left_ != nullptr) { levelnodes.push(next->left_); }    // add its children
      if (next->right_ != nullptr) { levelnodes.push(next->right_); }
    }
    std::cout << "\n";

    print_levelorder(root->left_, levelnodes);
    print_levelorder(root->right_, levelnodes);
  }

  //---- DATA MEMBERS ------------------------------------------------------------
private:
  treenode_<T>* root_;
  size_t size_;
};


template <typename T>
void find(const tree_<T>& tr, const T& data) {
  std::cout << "find " << data << " in the tree: ";
  treenode_<T>* p = tr.find(data);
  if (p == nullptr) { std::cout << "item not found\n";
  } else { std::cout << p->data_; }
  std::cout << "\n";
}

//                    60 21
//           40                 75 6
//     30          55        66        85 -1
//  25    35    50        65        80 4    90 -9
//
//  25 30 35 40 50 55 60  65 66 75  80 85 90

void test_tree() {
  begin_end_test bet(__FUNCTION__);
//  tree_<int> tr = { 60, 40, 80, 50, 90, 30, 45, 66, 75, 65, 85, 25, 35 };
  tree_<int> tr = { 60, 40, 25 };
  
  std::cout << "number of levels: " << tr.count_levels() << "\n";
  std::cout << "height of node with 60 is: " << tr.height_node(60) << "\n";
  std::cout << "height of node with 40 is: " << tr.height_node(40) << "\n";
  std::cout << "height of node with 25 is: " << tr.height_node(25) << "\n";

  tr.print();

  tr.insert(80);
  tr.insert(70);
  tr.insert(90);
  tr.insert(50);

  tr.insert(95);
  tr.insert(85);
  tr.insert(75);
  tr.insert(65);

  tr.insert(20);
  tr.insert(30);
  tr.insert(45);
  tr.insert(55);

  std::cout << "number of levels: " << tr.count_levels() << "\n";

  std::cout << "\n";
  tr.print();
  std::cout << "\nprinting PREORDER\n";
  tr.print(traversal::PREORDER);
  
  std::cout << "\nprinting LEVELORDER\n";
  tr.print(traversal::LEVELORDER);
  
  std::cout << "no children: "  << tr.count_nochildren() << "\n";
  std::cout << "one child: "    << tr.count_onechild() << "\n";
  std::cout << "two children: " << tr.count_twochildren() << "\n";

//  std::cout << "\nprinting INorder...\n";        tr.print();
//  std::cout << "\nprinting PREorder...\n";       tr.print(traversal::PREORDER);
//  std::cout << "\nprinting POSTorder...\n";      tr.print(traversal::POSTORDER);
//  std::cout << "\nprinting REVERSEorder...\n";   tr.print(traversal::REVERSE_INORDER);

//  find(tr, 45);
//  find(tr, 30);
//  find(tr, 12);
//
//  tr.findclosest(45);
//  tr.findclosest(81);
//  tr.findclosest(89);
//  tr.findclosest(60);
//  tr.findclosest(33);

//  tr.remove(25);
//  tr.remove(40);
//  tr.remove(70);
//  tr.remove(60);
}


#endif /* tree_h */
